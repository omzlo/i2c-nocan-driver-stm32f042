#ifndef _SYSTEM_H_
#define _SYSTEM_H_

void SystemInit(void);
void SystemCoreClockUpdate(void);
extern uint32_t SystemCoreClock;

#endif
