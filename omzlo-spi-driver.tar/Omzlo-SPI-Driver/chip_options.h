#ifndef _CHIP_OPTIONS_
#define _CHIP_OPTIONS_

void chip_options_configure(void);

extern const uint8_t* CHIP_UDID;

#endif
